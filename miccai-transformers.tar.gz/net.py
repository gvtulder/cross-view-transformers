import torch
import torch.nn as nn

models = {}
def register_model(cls):
    models[cls.__name__] = cls
    return cls

import net_ddsm
