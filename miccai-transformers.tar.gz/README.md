This code is part of the paper

Multi-view analysis of unregistered medical images using cross-view-transformers
by Gijs van Tulder, Yao Tong, Elena Marchiori

Accepted for MICCAI 2021.

